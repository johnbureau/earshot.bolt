#!/bin/bash

# Create directories if they don't exist
mkdir -p public/assets/images

# Download placeholder images using curl
# Dashboard preview
curl "https://placehold.co/1200x800/e2e8f0/475569?text=Modern+Event+Management+Dashboard" > public/assets/images/dashboard-preview.png

# Feature images
curl "https://placehold.co/800x600/e2e8f0/475569?text=Booking+Management+Interface" > public/assets/images/feature-booking.png
curl "https://placehold.co/800x600/e2e8f0/475569?text=Analytics+Dashboard" > public/assets/images/feature-analytics.png 