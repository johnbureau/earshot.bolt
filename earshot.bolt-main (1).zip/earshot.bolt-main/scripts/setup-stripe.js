import Stripe from 'stripe';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load environment variables from the root .env file
dotenv.config({ path: join(__dirname, '..', '.env') });

const stripe = new Stripe(process.env.VITE_STRIPE_SECRET_KEY);

async function createProductsAndPrices() {
  try {
    // Create Starter Product
    const starterProduct = await stripe.products.create({
      name: 'Starter',
      description: 'Perfect for individual creators and small events',
      metadata: {
        maxEvents: '12',
      },
      features: [
        'Up to 12 events per month',
        'Booking management',
        'Chat enabled',
        'Payment processing',
        'Basic analytics'
      ],
    });

    // Create Professional Product
    const professionalProduct = await stripe.products.create({
      name: 'Professional',
      description: 'Ideal for growing businesses and professional creators',
      metadata: {
        maxEvents: '30',
      },
      features: [
        'Up to 30 events per month',
        'Booking management',
        'Chat enabled',
        'Payment processing',
        'Basic analytics',
        'Advanced analytics',
        'Financial reporting',
        'Social Post Accelerator',
        'Priority support'
      ],
    });

    // Create prices for Starter
    const starterMonthly = await stripe.prices.create({
      product: starterProduct.id,
      unit_amount: 2000, // $20.00
      currency: 'usd',
      recurring: {
        interval: 'month',
      },
    });

    const starterAnnual = await stripe.prices.create({
      product: starterProduct.id,
      unit_amount: 19200, // $192.00 ($16/month with 20% discount)
      currency: 'usd',
      recurring: {
        interval: 'year',
      },
    });

    // Create prices for Professional
    const professionalMonthly = await stripe.prices.create({
      product: professionalProduct.id,
      unit_amount: 4000, // $40.00
      currency: 'usd',
      recurring: {
        interval: 'month',
      },
    });

    const professionalAnnual = await stripe.prices.create({
      product: professionalProduct.id,
      unit_amount: 38400, // $384.00 ($32/month with 20% discount)
      currency: 'usd',
      recurring: {
        interval: 'year',
      },
    });

    console.log('Products and prices created successfully:');
    console.log('\nStarter Plan:');
    console.log('Monthly Price ID:', starterMonthly.id);
    console.log('Annual Price ID:', starterAnnual.id);
    console.log('\nProfessional Plan:');
    console.log('Monthly Price ID:', professionalMonthly.id);
    console.log('Annual Price ID:', professionalAnnual.id);

    return {
      starter: {
        monthly: starterMonthly.id,
        annual: starterAnnual.id,
      },
      professional: {
        monthly: professionalMonthly.id,
        annual: professionalAnnual.id,
      },
    };
  } catch (error) {
    console.error('Error creating products and prices:', error);
    throw error;
  }
}

createProductsAndPrices(); 